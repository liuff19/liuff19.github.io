import torch.nn as nn
import math
import torch
import numpy as np
import torch.nn.functional as F
import random
from torch.autograd import Variable
import torchvision
import torchvision.transforms as transforms
import torch.optim as optim

import os

from utils import progress_bar

def adjust_learning_rate(optimizer, lr):
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def make_layers(cfg, batch_norm=False):
    layers = []
    extra_layers_encode = []
    in_channels = 3
    for v in cfg:
        if v == 'M':
            layers += [nn.MaxPool2d(kernel_size=2, stride=2)]
        else:
            conv2d = nn.Conv2d(in_channels, v, kernel_size=3, padding=1)
            layers += [conv2d, nn.ReLU()]
            extra_layers_encode += [nn.Linear(in_channels, 256), nn.ReLU()]
            in_channels = v
    layers = nn.ModuleList(layers)
    extra_layers_encode = nn.ModuleList(extra_layers_encode)
    return layers, extra_layers_encode

class pruning_model(nn.Module):
    def __init__(self, extra_layers_encode):
        super(pruning_model, self).__init__()
        self.extra_layers_encode = extra_layers_encode
        self.rnncell = nn.GRUCell(256, 4, bias=True)
        self._initialize_weights()
        self.relu = nn.ReLU()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()

    def forward(self, x, h, ct):
    	encode = self.extra_layers_encode[2*ct]
    	x = encode(x)
    	return self.rnncell(x, h)


class vgg_RPN(nn.Module):
    def __init__(self, conv_layers,extra_layers_encode, num_classes=1000):
        super(vgg_RPN, self).__init__()
        self.conv_layers = conv_layers
        self.extra_layers_encode = extra_layers_encode
        self.classifier = nn.Sequential(
            nn.Linear(512, 512),
            nn.ReLU(True),
            nn.Dropout(p=0.5),
            nn.Linear(512, num_classes),
        )
        self.rnncell = nn.GRUCell(256, 4, bias=True)
        self._initialize_weights()
        # mode = 0: VGG baseline
        # mode = 1: random pruning
        # mode = 2: RNP training
        self.mode = 0
        self.group = []
        self.greedyP = 0.9

    def divide_conv(self):
    	for layer in self.conv_layers:
    		if isinstance(layer, nn.Conv2d):
    			weights = layer.weight.data
    			weights = weights.view(weights.size(0), weights.size(1), -1)
    			norm = torch.norm(weights,2,2).cpu().numpy()
    			norm = np.mean(norm, 1)
    			order = np.argsort(norm)
    			glen = order.shape[0]/4
    			print glen, order.shape[0]
    			g0 = torch.from_numpy(np.sort(order[3*glen:]))
    			g1 = torch.from_numpy(np.sort(np.hstack((order[3*glen:], order[2*glen:3*glen]))))
    			g2 = torch.from_numpy(np.sort(np.hstack((order[3*glen:], order[2*glen:3*glen], order[glen:2*glen]))))
    			g3 = torch.from_numpy(np.sort(np.hstack((order[3*glen:], order[2*glen:3*glen], order[glen:2*glen], order[0:glen]))))
    			self.group += [[g0, g1, g2, g3]]

    def forward(self, x):
    	if self.mode == 0:
    		for layer in self.conv_layers:
    			#print layer
    			x = layer(x)
    		x = x.view(x.size(0), -1)
    		x = self.classifier(x)

    	if self.mode == 1:
    		ct = 0
    		bs = x.size(0)
    		for layer in self.conv_layers:
    			if isinstance(layer, nn.Conv2d) and ct > 0:
    				#choice = random.randint(0, 3)
    				#now_group = self.group[ct][choice]
    				#x = F.conv2d(x, layer.weight[former_group, now_group, :, :], layer.bias[now_group], kernel_size=3, padding=1)
    				x = layer(x)
    				mask = torch.zeros(x.size())
    				for i in range(bs):
    					choice = random.randint(0, 3)
    					now_group = self.group[ct][choice]
    					mask[i][now_group] = 1.0
    					#print mask.sum()
    				mask = Variable(mask, requires_grad=False).cuda()
    				x = mask*x
    				ct += 1
    			elif isinstance(layer, nn.Conv2d) and ct == 0:
    				x = layer(x)
    				ct += 1
    			else:
    				x = layer(x)
    		x = x.view(x.size(0), -1)
    		x = self.classifier(x)

    	if self.mode == 2:
    		y = []
    		ct = 0
    		bs = x.size(0)
    		former_state = Variable(torch.zeros(bs, 4)).cuda()
    		for layer in conv_layers:
    			if isinstance(layer, nn.Conv2d) and ct > 0:
    				#choice = random.randint(0, 3)
    				#now_group = self.group[ct][choice]
    				#x = F.conv2d(x, layer.weight[former_group, now_group, :, :], layer.bias[now_group], kernel_size=3, padding=1)
    				x_pool = x.mean(3).mean(2)
    				x = layer(x)
    				mask = torch.zeros(x.size())
    				h = pnet(x_pool, former_state, ct)
    				#x_input = self.extra_layers_encode[ct](x_pool)
    				#h = self.rnncell(x_input, former_state)
    				former_state = h
    				h_softmax_np = h.data.cpu().numpy()
    				choices = np.zeros((bs,), np.int)
    				for i in range(bs):
    					choice = np.argmax(h_softmax_np[i])
    					if random.random() > self.greedyP:
    						choice = random.randint(0, 3)
    					choices[i] = choice    						
    					now_group = self.group[ct][choice]
    					mask[i][now_group] = 1.0
    				mask = Variable(mask, requires_grad=False).cuda()
    				x = mask*x
    				y += [[h, choices]]
    				ct += 1

    			elif isinstance(layer, nn.Conv2d) and ct == 0:
    				x = layer(x)
    				ct += 1
    			else:
    				x = layer(x)
    		x = x.view(x.size(0), -1)
    		x = self.classifier(x)
    		return x, y
    	return x

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                m.weight.data.normal_(0, 0.01)
                m.bias.data.zero_()
        for m in self.conv_layers:
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
                if m.bias is not None:
                    m.bias.data.zero_()
        

cfg = [64, 64, 'M', 128, 128, 'M', 256, 256, 256, 'M', 512, 512, 512, 'M', 512, 512, 512, 'M']

conv_layers, extra_layers_encode = make_layers(cfg)
net = vgg_RPN(conv_layers, extra_layers_encode, 100)
net.cuda()

pnet = pruning_model(extra_layers_encode)
pnet.cuda()

transform_train = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

transform_test = transforms.Compose([
    transforms.ToTensor(),
    transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
])

trainset = torchvision.datasets.CIFAR100(root='./data', train=True, download=True, transform=transform_train)
trainloader = torch.utils.data.DataLoader(trainset, batch_size=128, shuffle=True, num_workers=2)

testset = torchvision.datasets.CIFAR100(root='./data', train=False, download=True, transform=transform_test)
testloader = torch.utils.data.DataLoader(testset, batch_size=100, shuffle=False, num_workers=2)

criterion = nn.CrossEntropyLoss()
criterion_rl = nn.MSELoss()
optimizer = optim.SGD(net.parameters(), lr=0.01, momentum=0.9, weight_decay=5e-5)
optimizer_rl = optim.Adam(pnet.parameters(), lr=0.0001, weight_decay=5e-5)


def train(epoch):
    print('\nEpoch: %d' % epoch)
    net.train()
    train_loss = 0
    raw_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(trainloader):
        inputs, targets = inputs.cuda(), targets.cuda()
        optimizer.zero_grad()
        inputs, targets = Variable(inputs), Variable(targets)
        outputs, y  = net(inputs)
        loss = criterion(outputs, targets)
        raw_loss += loss.data[0]
        loss.backward(retain_graph=True)
        optimizer.step()

        for i in range(len(y)):
            optimizer_rl.zero_grad()
            action = y[i][1]
            #print action.shape
            #print y[i][0].size()
            ind = Variable(torch.from_numpy(np.expand_dims(action,1)).cuda())
            state_action_values = y[i][0].gather(1,ind)
            if i < len(y) - 1:
                next_q = y[i+1][0].data.cpu().numpy()
                rtargets = -action*0.1 +  np.max(next_q, 1)
            else:
                rtargets = - action*0.1 - raw_loss

            rtargets = Variable(torch.from_numpy(rtargets.astype(np.float32)).cuda())
            loss_rl = criterion_rl(state_action_values, rtargets)
            loss_rl.backward(retain_graph=True)
            optimizer_rl.step()

        train_loss += loss.data[0]
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().sum()

        progress_bar(batch_idx, len(trainloader), 'Loss: %.3f Row_loss: %.3f | Acc: %.3f%% (%d/%d)'
            % (train_loss/(batch_idx+1), raw_loss/(batch_idx+1), 100.*correct/total, correct, total))

def test(epoch):
    global best_acc
    net.eval()
    test_loss = 0
    correct = 0
    total = 0
    for batch_idx, (inputs, targets) in enumerate(testloader):
        inputs, targets = inputs.cuda(), targets.cuda()
        inputs, targets = Variable(inputs, volatile=True), Variable(targets)
        outputs, y = net(inputs)
        loss = criterion(outputs, targets)

        test_loss += loss.data[0]
        _, predicted = torch.max(outputs.data, 1)
        total += targets.size(0)
        correct += predicted.eq(targets.data).cpu().sum()

        progress_bar(batch_idx, len(testloader), 'Loss: %.3f  | Acc: %.3f%% (%d/%d)'
            % (test_loss/(batch_idx+1), 100.*correct/total, correct, total))



nlr = 0.001
net.load_state_dict(torch.load('vgg16-cifar100.pth'))
net.mode = 2
net.divide_conv()

net.load_state_dict(torch.load('vgg16-cifar100-random.pth'))

for epoch in range(0, 100):
    if epoch % 25 == 0:
    	nlr = nlr / 2.0
        adjust_learning_rate(optimizer, nlr)
    
    train(epoch)
    test(epoch)
    torch.save(net.state_dict(), 'vgg16-cifar100-rl.pth')


